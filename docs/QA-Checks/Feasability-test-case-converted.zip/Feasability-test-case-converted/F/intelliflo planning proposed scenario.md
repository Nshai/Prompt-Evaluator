---
source_path: "F/intelliflo planning proposed scenario.pdf"
file_name: "intelliflo planning proposed scenario.pdf"
category_code: F
pages: 38
characters: 28794
converter: docling-serve (do_ocr=true, to_formats=md)
page_provenance: true
---

<!-- page: 1 -->

## SINGLE SCENARIO REPORT

<!-- image -->

Proposed scenario Prepared by Kyle Jenkinson 14/10/2025

<!-- image -->

<!-- page: 2 -->

## 1. Introduction to your plan

This report shows the financial plan for your scenario 'Proposed scenario '.

The financial plan has been produced using a forward-looking analysis of your assets, income and expenditure.

The aim of this plan is to help you make informed decisions regarding your future.

The analysis contained within this report is based on several assumptions including, but not limited to, inflation rates and investment returns. It is, therefore, subject to a number of risks and uncertainties. This forecast represents just one possible future outcome and actual results may differ materially from these projections.

All figures are in 'real' terms also known as 'today's money'. This means future values have been adjusted for the impact of inflation so that you can compare them to what they would be worth today.

## 2. Key definitions

- The Baseline Scenario refers to and reflects your current situation. 1.
- A Scenario is a version of your financial plan whereby one or more parameters have been amended from that 2. held in your Baseline.
- An Event is a single moment in time linked to a year, at which your financial circumstances may change. For 3. example, an event of 'Retire' may be linked to the year or age at which you would like to stop working. Income linked to this event could stop, as well as any anticipated change to your spending habits. Events are displayed on your plan timeline
- The term Liquid assets refers to your cash and investments as well as any capital held within a loan trust. 4.
- The term Non-liquid assets refers to those which are not always easy to sell or convert to cash quickly. This 5. includes property, possessions, business
- Pension - accessible refers to pension values that you could draw from (should you wish) because you have 6. already reached your minimum pension age (the age from which you can access pension benefits).
- Pension - non accessible refers to value held in pension that cannot be accessed because you have not yet 7. reached minimum pension age.
- The Surplus account is the account in which any surplus income is held. This is also the first liquid asset to be 8. drawn from if there is a shortfall.
- A Required withdrawal (Investments) is made from available liquid assets when there is a shortfall in a year 9. (where expenditure is greater than income).
- A Required withdrawal (Pensions) is made from accessible pensions when there is a shortfall in a year and it 10. cannot be met from liquid assets.
- The Surplus income percentage saved shows how much of any surplus (where your regular income exceeds 11. regular expenditure and tax) will be retained in your surplus account.
- Lifetime gifts are gifts that you have made to beneficiaries within the plan. Whilst gifts are potentially out of your 12. estate at the point of death, they are included in some projections to ensure benefits of any gifting are reflected in the plan.

<!-- page: 3 -->

## 3. Your plan assumptions

## Assumptions

## Expenditure Continuation on Death

Unless specified otherwise, expenditure will reduce to 80% on the death of and 80% on the death of

## Surplus Income Percentage Saved

0% of any in-year surplus will be saved within the plan

## Inflation Assumptions

The following inflation assumptions are the rates used throughout the plan, unless overridden on the individual entity basis

GENERAL 2 %

SCHOOL FEES 4 %

PROPERTY 4.7 %

LONG TERM CARE 4.5 %

STATE PENSION 2.5 %

LENDING 4 %

<!-- page: 4 -->

## 4. Proposed scenario

<!-- page: 5 -->

<!-- image -->

<!-- page: 6 -->

## Timeline

<!-- image -->

<!-- page: 7 -->

## Heads of Household

<!-- image -->

07/06/1956 - 69 years old

Relationship

Events

STATE PENSION AGE

66

<!-- image -->

07/05/1960 - 65 years old

Relationship Events

- Married to
- "Retire" age 66 in 2026, "Illness" age 100 in 2060, and "Death" age 100 in 2060
- Married to
- "Retire" age 71 in 2027, "Illness" age 100 in 2056, and "Death" age 100 in 2056

<!-- image -->

STATE PENSION AGE

66

MINIMUM PENSION AGE

55

<!-- image -->

MINIMUM PENSION AGE

55

<!-- image -->

KS

<!-- page: 8 -->

## Investments

## Surplus Account

## £0

LIQUIDATED 1ST

Return

## Savings

## £6,000

LIQUIDATED 2ND

| Type   | Cash Account              |
|--------|---------------------------|
| Return | 1.25% expected return p/a |
| Death  | Liquidated on death of    |

- 1.25% expected return p/a based on Cash risk profile

<!-- image -->

<!-- image -->

<!-- page: 9 -->

## Income

| Employed, CDH Recruitment £15,600 p/a (£300 Weekly) salary income until 2027 "Retire (John)" (inflated by 2% p/ a)   |
|----------------------------------------------------------------------------------------------------------------------|
| Sea Cadets £1,040 p/a (£20 Weekly) salary income until 2027 "Retire (John)" (inflated by 2% p/a)                     |
| Kims Income £13,200 p/a (£1,100 Monthly) salary income until 2026 "Retire (Kim)" (inflated by 2% p/a)                |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- page: 10 -->

## Pensions

## State Pension

State Pension of £11,973 (inflated by 2.5%) from age 66

## State Pension

State Pension of £11,973 (inflated by 2.5%) from age 66

## Aviva - SP50163762

EXCLUDED FROM SCENARIO UNCRYSTALLISED LIQUIDATION 3RD CRYSTALLISED LIQUIDATION 4TH

## Zurich -  P10026-719-001/DL

EXCLUDED FROM SCENARIO UNCRYSTALLISED LIQUIDATION 5TH CRYSTALLISED LIQUIDATION 6TH

## Standard Life - D2301334000

EXCLUDED FROM SCENARIO UNCRYSTALLISED LIQUIDATION 7TH CRYSTALLISED LIQUIDATION 8TH

## Peoples pension - 6197175/PP

## £6,601

Uncrystallised fund value

UNCRYSTALLISED LIQUIDATION 9TH CRYSTALLISED LIQUIDATION 10TH

<!-- image -->

| Type   | Defined Contribution Occupational                                                  |
|--------|------------------------------------------------------------------------------------|
| Return | Currently 2.5% expected return p/a                                                 |
| Fees   | Currently 0.5% ongoing platform/fund charges and 0% ongoing financial planning fee |
| Death  | Transfer to spouse on death of                                                     |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- page: 11 -->

## Scottish Widows - ZU4225575

## £211

Uncrystallised fund value

UNCRYSTALLISED LIQUIDATION 11TH CRYSTALLISED LIQUIDATION 12TH

Type

- Defined Contribution Occupational

Return

- Currently 2% expected return p/a based on Low risk profile

Fees

- Currently 0.29% ongoing platform/fund charges and 0% ongoing financial planning fee

Death

- Transfer to spouse  on death of

## New Aviva pension

## £110,185

Uncrystallised fund value

EXCLUDED IN BASELINE UNCRYSTALLISED LIQUIDATION 13TH CRYSTALLISED LIQUIDATION 14TH

Type

- Defined Contribution Personal Pension

Return

- Currently 5% expected return p/a based on Medium risk profile

Fees

- Currently 0.44% ongoing platform/fund charges and 1% ongoing financial planning fee

Death

- Transfer to spouse  on death of

<!-- image -->

<!-- image -->

<!-- image -->

<!-- page: 12 -->

## Expenses

## Entertainment &amp; Leisure

## Household

Living

Miscellaneous

## Transport

TOTAL REGULAR EXPENSES

£20,616

<!-- image -->

- Currently £1,200 p/a (discretionary) increasing by 2% p/a
- Currently £15,660 p/a (essential) increasing by 2% p/a
- Currently £1,656 p/a (essential) increasing by 2% p/a
- Currently £300 p/a (essential) increasing by 2% p/a
- Currently £1,800 p/a (essential) increasing by 2% p/a

<!-- page: 13 -->

## 5. Proposed scenario  - projections

## Asset Statement

This table shows the opening value of your assets for each year of the plan, after any deductions have been made for a shortfall in the previous plan year. The values displayed are in 'real' terms.

|   Year | Age     |   Liquid Assets (£) |   Pensions - Accessible (£) |   Pensions - Non Accessible (£) |   Property (£) |   Business (£) |   Possessions (£) |   Total (£) |
|--------|---------|---------------------|-----------------------------|---------------------------------|----------------|----------------|-------------------|-------------|
|   2025 | 69 / 65 |               6,000 |                     116,997 |                               0 |              0 |              0 |                 0 |     122,997 |
|   2026 | 70 / 66 |               5,956 |                     118,632 |                               0 |              0 |              0 |                 0 |     124,588 |
|   2027 | 71 / 67 |               5,912 |                     120,292 |                               0 |              0 |              0 |                 0 |     126,204 |
|   2028 | 72 / 68 |               5,869 |                     121,976 |                               0 |              0 |              0 |                 0 |     127,845 |
|   2029 | 73 / 69 |               5,825 |                     123,685 |                               0 |              0 |              0 |                 0 |     129,511 |
|   2030 | 74 / 70 |               5,783 |                     125,420 |                               0 |              0 |              0 |                 0 |     131,203 |
|   2031 | 75 / 71 |               5,740 |                     127,181 |                               0 |              0 |              0 |                 0 |     132,921 |
|   2032 | 76 / 72 |               5,698 |                     128,967 |                               0 |              0 |              0 |                 0 |     134,665 |
|   2033 | 77 / 73 |               5,656 |                     130,780 |                               0 |              0 |              0 |                 0 |     136,436 |
|   2034 | 78 / 74 |               5,614 |                     132,620 |                               0 |              0 |              0 |                 0 |     138,235 |
|   2035 | 79 / 75 |               5,573 |                     134,488 |                               0 |              0 |              0 |                 0 |     140,061 |
|   2036 | 80 / 76 |               5,532 |                     136,383 |                               0 |              0 |              0 |                 0 |     141,915 |
|   2037 | 81 / 77 |               5,491 |                     138,306 |                               0 |              0 |              0 |                 0 |     143,798 |
|   2038 | 82 / 78 |               5,451 |                     140,258 |                               0 |              0 |              0 |                 0 |     145,709 |
|   2039 | 83 / 79 |               5,411 |                     142,239 |                               0 |              0 |              0 |                 0 |     147,650 |
|   2040 | 84 / 80 |               5,371 |                     144,249 |                               0 |              0 |              0 |                 0 |     149,620 |
|   2041 | 85 / 81 |               5,332 |                     146,289 |                               0 |              0 |              0 |                 0 |     151,621 |
|   2042 | 86 / 82 |               5,293 |                     148,359 |                               0 |              0 |              0 |                 0 |     153,652 |
|   2043 | 87 / 83 |               5,254 |                     150,461 |                               0 |              0 |              0 |                 0 |     155,714 |
|   2044 | 88 / 84 |               5,215 |                     152,593 |                               0 |              0 |              0 |                 0 |     157,808 |
|   2045 | 89 / 85 |               5,177 |                     154,757 |                               0 |              0 |              0 |                 0 |     159,934 |
|   2046 | 90 / 86 |               5,139 |                     156,953 |                               0 |              0 |              0 |                 0 |     162,092 |
|   2047 | 91 / 87 |               5,101 |                     159,182 |                               0 |              0 |              0 |                 0 |     164,283 |

<!-- page: 14 -->

|   Year | Age       |   Liquid Assets (£) |   Pensions - Accessible (£) |   Pensions - Non Accessible (£) |   Property (£) |   Business (£) |   Possessions (£) |   Total (£) |
|--------|-----------|---------------------|-----------------------------|---------------------------------|----------------|----------------|-------------------|-------------|
|   2048 | 92 / 88   |               5,063 |                     161,444 |                               0 |              0 |              0 |                 0 |     166,507 |
|   2049 | 93 / 89   |               5,026 |                     163,739 |                               0 |              0 |              0 |                 0 |     168,765 |
|   2050 | 94 / 90   |               4,989 |                     166,069 |                               0 |              0 |              0 |                 0 |     171,058 |
|   2051 | 95 / 91   |               4,952 |                     168,433 |                               0 |              0 |              0 |                 0 |     173,385 |
|   2052 | 96 / 92   |               4,916 |                     170,832 |                               0 |              0 |              0 |                 0 |     175,748 |
|   2053 | 97 / 93   |               4,880 |                     173,267 |                               0 |              0 |              0 |                 0 |     178,147 |
|   2054 | 98 / 94   |               4,844 |                     175,738 |                               0 |              0 |              0 |                 0 |     180,582 |
|   2055 | 99 / 95   |               4,808 |                     178,246 |                               0 |              0 |              0 |                 0 |     183,054 |
|   2056 | 100 / 96  |               4,773 |                     180,791 |                               0 |              0 |              0 |                 0 |     185,564 |
|   2057 | 101 / 97  |               1,865 |                     183,374 |                               0 |              0 |              0 |                 0 |     185,239 |
|   2058 | 102 / 98  |                   0 |                     185,027 |                               0 |              0 |              0 |                 0 |     185,027 |
|   2059 | 103 / 99  |                   0 |                     184,732 |                               0 |              0 |              0 |                 0 |     184,732 |
|   2060 | 104 / 100 |                   0 |                     184,141 |                               0 |              0 |              0 |                 0 |     184,141 |

<!-- page: 15 -->

## Liquid Asset and Defined Contribution Statements

This section details the value of your cash and investments as well as pensions and any capital held in loan trusts. Any liabilities are also displayed. All values are the opening values of the first year of the plan.

## Savings &amp; Investments

| Investment Description   | Owner   | Product Type    |   Opening Value (£) |
|--------------------------|---------|-----------------|---------------------|
| Surplus Account          | JS / KS | Surplus Account |                   0 |
| Savings                  | JS      | Cash Account    |               6,000 |
| Total                    |         |                 |               6,000 |

## Defined Contribution Pensions

| Pension Description          | Owner   |   Opening Value (£) |
|------------------------------|---------|---------------------|
| Peoples pension - 6197175/PP | JS      |               6,601 |
| Scottish Widows - ZU4225575  | JS      |                 211 |
| New Aviva pension            | JS      |             110,185 |
| Total                        |         |             116,997 |

## Loan Trusts

| Description   |   Opening Value (£) |
|---------------|---------------------|
| Total         |                   0 |

## Liabilities

<!-- page: 16 -->

| Description   |   Opening Value (£) |
|---------------|---------------------|
| Total         |                   0 |

<!-- page: 17 -->

## Cashflow Statement

This table provides a summary cashflow statement for each year of your plan. The value of liquid assets and accessible pensions shows the opening value for each year of the plan, after any deductions have been made for a shortfall in the previous plan year.

- Your total money in will include any regular income such as employment income and one-off inflows including asset sales.
- Your total money out includes any regular expenditure and irregular outflows such as an asset purchase or gift.
- The surplus/deficit is the balance of total money in minus total money out. This figure is then adjusted in accordance with the surplus income percentage saved assumption.

Where there is a deficit, a drawing from liquid assets and/or accessible pensions is made to meet the shortfall.

|   Year | Age     |   Liquid Assets & Accessible Pensions (£) |   Total Money In (£) |   In Year Surplus / Deficit (£) |   In Year Surplus / Deficit (£) |
|--------|---------|-------------------------------------------|----------------------|---------------------------------|---------------------------------|
|   2025 | 69 / 65 |                                   122,997 |               41,813 |                          24,001 |                               0 |
|   2026 | 70 / 66 |                                   124,588 |               40,703 |                          23,886 |                               0 |
|   2027 | 71 / 67 |                                   126,204 |               24,181 |                          20,620 |                               0 |
|   2028 | 72 / 68 |                                   127,845 |               24,300 |                          20,643 |                               0 |
|   2029 | 73 / 69 |                                   129,511 |               24,419 |                          20,667 |                               0 |
|   2030 | 74 / 70 |                                   131,203 |               24,539 |                          20,691 |                               0 |
|   2031 | 75 / 71 |                                   132,921 |               24,659 |                          20,715 |                               0 |
|   2032 | 76 / 72 |                                   134,665 |               24,780 |                          20,739 |                               0 |
|   2033 | 77 / 73 |                                   136,436 |               24,901 |                          20,764 |                               0 |
|   2034 | 78 / 74 |                                   138,235 |               25,023 |                          20,788 |                               0 |
|   2035 | 79 / 75 |                                   140,061 |               25,146 |                          20,812 |                               0 |
|   2036 | 80 / 76 |                                   141,915 |               25,269 |                          20,837 |                               0 |
|   2037 | 81 / 77 |                                   143,798 |               25,393 |                          20,862 |                               0 |
|   2038 | 82 / 78 |                                   145,709 |               25,518 |                          20,887 |                               0 |
|   2039 | 83 / 79 |                                   147,650 |               25,643 |                          20,912 |                               0 |
|   2040 | 84 / 80 |                                   149,620 |               25,768 |                          20,937 |                               0 |
|   2041 | 85 / 81 |                                   151,621 |               25,895 |                          20,962 |                               0 |
|   2042 | 86 / 82 |                                   153,652 |               26,022 |                          20,988 |                               0 |
|   2043 | 87 / 83 |                                   155,714 |               26,149 |                          21,013 |                               0 |
|   2044 | 88 / 84 |                                   157,808 |               26,277 |                          21,039 |                               0 |

<!-- page: 18 -->

|   Year | Age       |   Liquid Assets & Accessible Pensions (£) |   Total Money In (£) |   In Year Surplus / Deficit (£) | In Year Surplus / Deficit (£)   |
|--------|-----------|-------------------------------------------|----------------------|---------------------------------|---------------------------------|
|   2045 | 89 / 85   |                                   159,934 |               26,406 |                          21,064 | 0                               |
|   2046 | 90 / 86   |                                   162,092 |               26,536 |                          21,090 | 0                               |
|   2047 | 91 / 87   |                                   164,283 |               26,666 |                          21,116 | 0                               |
|   2048 | 92 / 88   |                                   166,507 |               26,796 |                          21,143 | 0                               |
|   2049 | 93 / 89   |                                   168,765 |               26,928 |                          21,169 | 0                               |
|   2050 | 94 / 90   |                                   171,058 |               27,060 |                          21,195 | 0                               |
|   2051 | 95 / 91   |                                   173,385 |               27,192 |                          21,222 | 0                               |
|   2052 | 96 / 92   |                                   175,748 |               27,326 |                          21,248 | 0                               |
|   2053 | 97 / 93   |                                   178,147 |               27,460 |                          21,275 | 0                               |
|   2054 | 98 / 94   |                                   180,582 |               27,594 |                          21,302 | 0                               |
|   2055 | 99 / 95   |                                   183,054 |               27,730 |                          21,329 | 0                               |
|   2056 | 100 / 96  |                                   185,564 |               13,933 |                          16,863 | (2,930)                         |
|   2057 | 101 / 97  |                                   185,239 |               14,001 |                          16,877 | (2,876)                         |
|   2058 | 102 / 98  |                                   185,027 |               14,070 |                          17,084 | (3,014)                         |
|   2059 | 103 / 99  |                                   184,732 |               14,139 |                          17,495 | (3,357)                         |
|   2060 | 104 / 100 |                                   184,141 |                    0 |                               0 | 0                               |

<!-- page: 19 -->

## Income Statement - First Year of Plan

| Income               |    (£) |   (£) |   Combined (£) |   Combined (£) |
|----------------------|--------|-------|----------------|----------------|
| State Pension        | 11,973 |     0 |                |         11,973 |
| Employment           | 16,640 |       |         13,200 |         29,840 |
| Total Regular Income | 28,613 |       |         13,200 |         41,813 |

<!-- page: 20 -->

## Regular Expenditure Statement - First Year of Plan

| Item                      |   Amount (£) |
|---------------------------|--------------|
| Tax & NI                  |        3,385 |
| General Expenses          |              |
| Entertainment & Leisure   |        1,200 |
| Household                 |       15,660 |
| Living                    |        1,656 |
| Transport                 |        1,800 |
| Miscellaneous             |          300 |
| Total Regular Expenditure |       24,001 |

<!-- page: 21 -->

## 6. Proposed scenario  - projection graphs

This section shows the projection graphs for the scenario Proposed scenario .

Interpreting the graphs:

A graph that goes into the red means that all available liquid assets have been drawn and there are no funds available to meet any shortfall.

The term liquid assets refers to your cash and investments as well as any capital held within a loan trust.

The term non-liquid assets refers to those which are not always easy to sell or convert to cash quickly. This includes property, possessions, business.

Pension - accessible refers to pension values that you could draw from (should you wish) because you have already reached your minimum pension age (the age from which you can access pension benefits).

Pension - non accessible refers to value held in pension that cannot be accessed because you have not yet reached minimum pension age.

A required Withdrawal (Investments) is made from available liquid assets when there is a shortfall in a year (where expenditure is greater than income).

A required Withdrawal (Pensions) is made from accessible pensions when there is a shortfall in a year and it cannot be met from liquid assets.

<!-- page: 22 -->

## Liquid Assets

This graph shows your liquid assets, net of any liabilities

<!-- image -->

<!-- page: 23 -->

## Liquid Assets Detail

This graph shows a breakdown of your liquid assets. The black line represents any outstanding liabilities. This does not include your accessible pensions.

<!-- image -->

<!-- page: 24 -->

## Liquid Assets &amp; Pensions

This graph shows your liquid assets and accessible defined contribution pensions, net of any liabilities

<!-- image -->

<!-- page: 25 -->

## Liquid Assets &amp; Pensions Detail

This graph shows a breakdown of your liquid assets and accessible defined contribution pensions. The black line represents any outstanding liabilities.

<!-- image -->

<!-- page: 26 -->

## Non Liquid Assets &amp; Pensions

This graph shows your non-liquid assets and non- accessible defined contribution pensions.

<!-- page: 27 -->

## Total Assets

This graph shows your total assets categorised as liquid assets, property, possessions and defined contribution pensions. The value of liquid assets is net of any liabilities.

<!-- image -->

<!-- page: 28 -->

## Total Assets Detail

This graph shows a breakdown of your total assets. The black line represents any outstanding liabilities.

<!-- image -->

<!-- page: 29 -->

## Summary Cashflow

The black line on this graph reflects your expenditure (including tax &amp; NI) throughout the plan. The graph shows how this expenditure is met (or exceeded) each year. Where there is a shortfall, a Required Withdrawal is made. Red bars indicate that there are insufficient liquid assets or accessible pensions to meet the shortfall.

<!-- image -->

<!-- page: 30 -->

## Regular Expenditure Detail

This graph shows a breakdown of your regular expenditure throughout the plan as well as any custom expenses added as a one-off or periodically. It does not include oneoff items such as the purchase of property or possessions, gifts, or the repayment of interest only liabilities.

<!-- image -->

<!-- page: 31 -->

## Total Regular Expenditure

This graph shows your total regular expenditure throughout the plan as well as any custom expenses added as a one-off or periodically. It does not include one-off items such as the purchase of property or possessions, gifts, or the repayment of interest only liabilities This graph shows the personal taxes and National Insurance you may pay each year of the plan

<!-- image -->

<!-- page: 32 -->

Tax

<!-- image -->

<!-- page: 33 -->

## Cumulative Tax

This graph shows the personal taxes and National Insurance may pay cumulatively over the plan.

<!-- image -->

<!-- page: 34 -->

## Beneficiaries Fund

This graph shows the value of assets in the hands of your beneficiaries. These values include gifts added to your plan as well as the transfer of assets upon first death (where there are two people in the plan). The values shown here are outside of your estate for inheritance tax purposes.

<!-- page: 35 -->

## Estate on Death

This graph shows your estate on death position every year of the plan. The Inheritance Tax (IHT) liability is tax due on death. If there are two people in the plan, this assumes both people die in the same year. Gifts that fall within your estate for IHT purposes are also included.

<!-- image -->

<!-- page: 36 -->

## Cumulative Estate on Death

This graph shows your cumulative estate on death position every year of the plan. This reflects all assets given to beneficiaries, as well as the IHT liability due on first death. Gifts made during the life of the plan are included even if they are outside of your estate for IHT calculations

<!-- image -->

<!-- page: 37 -->

## Total Liabilities Detail

This graph shows a breakdown of all mortgage and liabilities JTFAS

<!-- page: 38 -->

<!-- image -->
