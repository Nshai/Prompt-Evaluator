---
source_path: "E/People's Pension Fund FactSheet.pdf"
file_name: "People's Pension Fund FactSheet.pdf"
category_code: E
pages: 2
characters: 3849
converter: docling-serve (do_ocr=true, to_formats=md)
page_provenance: true
---

<!-- page: 1 -->

## Global Investments (up to 85% shares) 0.5% Pn

## 31/12/2023

Important Notes This document is provided for the purpose of information only and should not be construed in any way as giving investment advice. Past performance is not necessarily a guide to future performance, as the value of the units may go up or down and any return is not guaranteed. The price of the units can be monitored on our website at bandce.co.uk/fund-unit-prices

## Investment objective

The People's Pension Global Investments (up to 85% Shares) Fund aims to achieve long-term capital growth by investing in a range of asset classes in the UK and overseas. These can include, but are not limited to, equities, government bonds, corporate bonds. The fund is medium / high risk and will typically hold up to 85% in equities, with a mix of UK and overseas equities.

## Cumulative performance (as at 31/12/2023)

<!-- image -->

31/12/2018 - 29/12/2023 Powered by data from FE fundinfo

<!-- image -->

<!-- image -->

- Fund 0

Benchmark

## Cumulative performance (as at 31/12/2023)

|           | 5y     | 3y     | 1y     | 6m    | 3m    | 1m    |
|-----------|--------|--------|--------|-------|-------|-------|
| Fund      | 38.90% | 11.28% | 10.81% | 5.97% | 7.42% | 4.33% |
| Benchmark | 39.64% | 30.35% | 6.52%  | 1.78% | 0.77% | 0.58% |

## Discrete performance (as at 31/12/2023)

|           | 31/12/2018 - 31/12/2019   | 31/12/2019 - 31/12/2020   | 31/12/2020 - 31/12/2021   | 31/12/2021 - 31/12/2022   | 31/12/2022 - 31/12/2023   |
|-----------|---------------------------|---------------------------|---------------------------|---------------------------|---------------------------|
| Fund      | 18.35%                    | 5.47%                     | 13.99%                    | -11.90%                   | 10.81%                    |
| Benchmark | 3.84%                     | 3.16%                     | 8.04%                     | 13.27%                    | 6.52%                     |

Source: FE fundinfo. Fund, Sector and Index performance is shown in local currency, on a single price basis with income re-invested into the fund.

<!-- image -->

## Fund facts

| Single Price:      | £1109.10                       |
|--------------------|--------------------------------|
| Currency:          | British Pound                  |
| Pricing Frequency: | Daily                          |
| Launch Date:       | 03/01/2013                     |
| Fund Size:         | £19,541.03m                    |
| Benchmark:         | UK Consumer Price Index + 2.5% |
| Initial Charge:    | 0.00%                          |
| AMC/OCF:           | 0.50%                          |
| Citicode:          | KOVU                           |
| ISIN:              | GB00BYY2NM29                   |
| SEDOL:             | BYY2NM2                        |

<!-- image -->

<!-- page: 2 -->

## Global Investments (up to 85% shares) 0.5% Pn

31/12/2023

## Region breakdown

<!-- image -->

## Asset breakdown

<!-- image -->

## Sector breakdown

<!-- image -->

## Current top 10 holdings

| MICROSOFT CORPORATION           | 1.2%   |
|---------------------------------|--------|
| APPLE INC.                      | 1.0%   |
| PROLOGIS INC                    | 0.7%   |
| UNITEDHEALTH GROUP INCORPORATED | 0.5%   |
| NVIDIA CORP                     | 0.5%   |
| NOVO NORDISK A/S                | 0.5%   |
| ADOBE INC.                      | 0.5%   |
| CISCO SYSTEMS, INC.             | 0.4%   |
| EQUINIX, INC.                   | 0.4%   |
| INTEL CORPORATION               | 0.4%   |

Contributions are currently invested on behalf of the Trustee by State Street Global Advisors (SSGA). The Top 10 Holdings relate to equites only.

## Contact information

The People's Pension Trustee Limited Manor Royal, Crawley, West Sussex, RH10 9QP. Tel 0300 2000 555

www.thepeoplespension.co.uk
