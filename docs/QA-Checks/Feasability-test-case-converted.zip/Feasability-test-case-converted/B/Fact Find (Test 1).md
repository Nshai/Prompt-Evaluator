---
source_path: "B/Fact Find (Test 1).pdf"
file_name: "Fact Find (Test 1).pdf"
category_code: B
pages: 17
pdf_pages: 17
characters: 40731
converter: docling-serve (do_ocr=true, to_formats=md, per-page page_range)
page_provenance: true
---

<!-- page: 1 -->

## Your Information

## Private and Confidential

Client One:

Alan

<!-- image -->

Adviser:

Date Completed: 19/09/2025

My advice is based on the information contained within this document. Unanswered questions or blank responses will be excluded from any advice given. If any details are incorrect or omitted, please let me know as this may impact on the suitability of the advice.

JTFAS

<!-- image -->

WEALTH

<!-- page: 2 -->

## Advice Areas

| Date of Meeting                      | 18/09/2025            |
|--------------------------------------|-----------------------|
| Type of Meeting                      | Video Call - Recorded |
| Anybody else present at the Meeting? | No                    |
| Please provide details               |                       |
| Protection                           |                       |
| Mortgage                             |                       |
| Retirement Planning                  | Yes                   |
| Savings & Investments                |                       |
| Estate Planning                      |                       |

## Data Protection

| Client             |                                                                                                                                                                                                                                                                |                    |
|--------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------|
| Agreement Date     | 01/09/2025                                                                                                                                                                                                                                                     |                    |
| Statement 1        | We take your privacy seriously and want to be transparent about how we handle your information. Key points you should know - TFAS is a group of UK-registered companies providing telephone and video-based financial advice.                                  |                    |
| Statement 1        | Yes                                                                                                                                                                                                                                                            | Answer             |
| Statement          | We collect your data directly or from third parties (e.g. introducers, providers, legal firms). We may share data with trusted third parties (e.g. service providers, regulators) when necessary. We won't share your data for marketing without your consent. | 2                  |
| Statement 2 Answer | Yes                                                                                                                                                                                                                                                            |                    |
| Statement          | We use AI to transcribe and record calls to support service quality and compliance.                                                                                                                                                                            | 3                  |
| Statement 3        | Yes                                                                                                                                                                                                                                                            | Answer             |
| Statement 4        | Your data may be transferred outside the UK with appropriate safeguards in place. Information is kept secure and only for as long as needed. Recommendations are stored indefinitely.                                                                          |                    |
|                    | Yes                                                                                                                                                                                                                                                            | Statement 4 Answer |
| Statement 5        | You have rights under data protection law, including access, correction, deletion, and objection. Our full privacy policy is available on request or via our website. Are you happy to proceed on this basis?                                                  |                    |
| Statement 5 Answer | Yes                                                                                                                                                                                                                                                            |                    |

<!-- page: 3 -->

## Personal Details

| Title                                                                                                                      | Mr             |
|----------------------------------------------------------------------------------------------------------------------------|----------------|
| First Name                                                                                                                 |                |
| Middle Name                                                                                                                | Alan           |
| Last Name                                                                                                                  |                |
| Preferred Name                                                                                                             |                |
| Maiden/Previous Name                                                                                                       |                |
| Date of Birth                                                                                                              | 07/06/1956     |
| Age                                                                                                                        | 70             |
| Gender                                                                                                                     | Male           |
| Marital Status                                                                                                             | Married        |
| Since                                                                                                                      |                |
| Nationality                                                                                                                | British        |
| National Insurance No.                                                                                                     | YW377231C      |
| Country Of Domicile                                                                                                        | United Kingdom |
| Country Of Residence                                                                                                       |                |
| Expatriate?                                                                                                                | No             |
| Country of Birth                                                                                                           | United Kingdom |
| Place of Birth                                                                                                             |                |
| Do you have a valid Will?                                                                                                  | Yes            |
| Is it up-to-date?                                                                                                          | No             |
| Has the client been advised to make a will?                                                                                | Yes            |
| Power Of Attorney Granted?                                                                                                 | No             |
| Are you a smoker?                                                                                                          | No             |
| Have you smoked in the last 12 months?                                                                                     | No             |
| Have you ever smoked?                                                                                                      | No             |
| Have you vaped or used e-cigarettes in the last year?                                                                      | No             |
| Have you used other nicotine replacement products in the last year?                                                        | No             |
| Are you currently in good health? If No, please provide details                                                            | Yes            |
| Any medical conditions (including date diagnosed)?                                                                         |                |
| Are there any particular social, ethical, environmental and/or religious considerations that should be taken into account? | No             |

<!-- image -->

<!-- image -->

<!-- page: 4 -->

## Contact Address

|                              |                  | Addressee   |
|------------------------------|------------------|-------------|
| Address Line                 | 42 Egmont Road   | 1           |
| Address Line 2               |                  |             |
| Address Line 3               |                  |             |
| Address Line 4               |                  |             |
| City /                       | Hove             | Town        |
|                              | United Kingdom   | Country     |
|                              | BN3 7FP          | Postcode    |
| Address Type                 | Home             |             |
| Residency Status             | Tenant - private |             |
| Date                         |                  | From        |
| Date                         |                  | To          |
| Default                      |                  |             |
| Address                      | Current Address  | Status      |
| Registered on Electoral Roll |                  |             |
| Time at Address (Months)     |                  |             |

## Contact Details

Name Contact Type Mobile E-Mail

## Family And Dependants

Full Name Date of Birth

07/05/1960

Age

65

Value

07707054244

Relationship

Spouse Related To Note Financially Dependent?

No Period Preferred Contact Yes Yes Dependant Living with Client(s)

Yes

<!-- page: 5 -->

## ID Verification

Original Driving Licence Seen

08/12/2025

Driving Licence Ref

SULLI506076JA9SL

Driving Licence Expiry Date

10/06/2026

Original Passport Seen

Country of Origin

Passport ref

Passport Expiry Date

Mother's Maiden Name

Electricity Bill Ref

Inland Revenue Tax Notification

08/12/2025

Home Visit

Premises Entered

Bank Statement Seen

Mortgage Statement Seen

Council Tax Bill Seen

Utilities Bill Seen

Original Firearm/Shotgun Certificate Seen

Firearm/Shotgun Certificate Ref

Firearm/Shotgun Certificate Expiry Date

Microfiche Issue Date

Microfiche number

## Electronic ID Verification

ID Check Completed Date

08/12/2025

ID Check Expiry Date

01/06/2026

## Profile Notes

## Current Employment Details

Total annual self-employed Gross Profit, Dividend, and Salary / employed gross basic, guaranteed and regular overtime and bonus incomes

£ 0.00

Highest rate of income tax paid (%)

0

<!-- page: 6 -->

|                                                     |                 | Owner                             |
|-----------------------------------------------------|-----------------|-----------------------------------|
|                                                     | Employed        | Employment Status                 |
| Business Type                                       |                 |                                   |
|                                                     | HGV Driver      | Occupation                        |
|                                                     | CDH Recruitment | Employer                          |
| Address Line                                        |                 | 1                                 |
| Address Line                                        |                 | 2                                 |
| Address Line                                        |                 | 3                                 |
| Address Line                                        |                 | 4                                 |
| City /                                              |                 | Town                              |
|                                                     |                 | County/state/province             |
| Country                                             | United Kingdom  |                                   |
| Post                                                |                 | Code                              |
| Intended Retirement Age                             | 72              |                                   |
| Start Date                                          |                 |                                   |
| End Date                                            |                 |                                   |
|                                                     |                 | Description                       |
| Most Recent Annual Accounts Gross Profit            |                 |                                   |
| Most Recent Annual Accounts Net Profit              |                 |                                   |
| Most Recent Annual Accounts Gross Dividend          |                 |                                   |
| Most Recent Annual Accounts Net Dividend            |                 |                                   |
| Most Recent Annual Accounts Gross Salary            |                 |                                   |
| Most Recent Annual Accounts Net Salary              |                 |                                   |
| Most Recent Annual Accounts Share of Company Profit |                 |                                   |
| Year End                                            |                 | Most Recent Annual Accounts       |
| Year 2 Annual Accounts Gross Profit                 |                 |                                   |
| Year 2 Annual Accounts Net Profit                   |                 |                                   |
| Year 2 Annual Accounts Gross Dividend               |                 |                                   |
| Year 2 Annual Accounts Net Dividend                 |                 |                                   |
| Salary                                              |                 | Year 2 Annual Accounts Gross      |
| Year 2 Annual Accounts Net Salary                   |                 |                                   |
| Year 2 Annual Accounts Share of Company Profit      |                 |                                   |
| Year 2 Year                                         |                 | End                               |
| Year 3 Annual Accounts Gross Profit                 |                 |                                   |
| Year 3 Annual Accounts Net Profit                   |                 |                                   |
| Dividend                                            |                 | Year 3 Annual Accounts Gross      |
| Year 3 Annual Accounts Net Dividend                 |                 |                                   |
| Salary                                              |                 | Year 3 Annual Accounts Gross      |
|                                                     |                 | Year 3 Annual Accounts Net Salary |
| Year 3 Annual Accounts Share of Company Profit      |                 |                                   |
| Year 3 Year                                         |                 | End                               |

<!-- page: 7 -->

| Gross Basic Annual Income        |            |          |
|----------------------------------|------------|----------|
| Net Basic Monthly Income         | £ 1,200.00 |          |
| Do you receive Overtime Income?  | No         |          |
| Gross Guaranteed Annual Overtime |            |          |
| Net Guaranteed Monthly Overtime  |            |          |
| Gross Regular Annual Overtime    |            |          |
| Net Regular Monthly              |            | Overtime |
| Do you receive Bonus Income?     | No         |          |
| Gross Guaranteed Annual Bonus    |            |          |
| Net Guaranteed Annual Bonus      |            |          |
| Gross Regular Annual Bonus       |            |          |
| Net Regular Annual Bonus         |            |          |
| Other Gross Income               |            |          |
| Other Gross Income Description   |            |          |
| Total Gross Annual               |            | Earnings |
| Continuous Employment (Months)   |            |          |
| In Probation                     | No         |          |
| Probation Period (Months)        |            |          |

## Employment Notes

## Assets

Do you have any assets?

Client did not disclose Yes No Total

| Owner   | Category   | Related to Address   | Description   | Owner 1 %   | Owner 2 %   | Cur.   | Original Value   | Purchased On   | Value      | Valuation Date   | Net Monthly Income   |
|---------|------------|----------------------|---------------|-------------|-------------|--------|------------------|----------------|------------|------------------|----------------------|
|         | Cash       |                      | Savings       |             |             | GBP    |                  |                | £ 6,000.00 | 22/09/2025       |                      |

£6,000.00

<!-- page: 8 -->

## Liabilities

It is desirable that a greater priority be given to the repayment / reduction of the levels of your debt prior to making an investment or committing to a regular premium.

Do you have any liabilities?

## Credit History

Have you ever been refused a mortgage / credit?

Do you have an adverse Credit History?

## Asset &amp; Liability Notes

## Income

Total annual self-employed Gross Profit, Dividend, and Salary / employed gross basic, guaranteed and regular overtime and bonus incomes

Total Gross Annual Earnings or Net Relevant Earnings

<!-- image -->

<!-- image -->

| Owner   | Category      | Descriptio n               | Frequency   | Gross Amount   | Net Amount   | Start Date   | End Date   | Last Updated   | Occupatio n   | Descriptio n   |
|---------|---------------|----------------------------|-------------|----------------|--------------|--------------|------------|----------------|---------------|----------------|
|         | Basic Income  | Employed, CDH Recruitmen t | Monthly     | £ 0.00         | £ 1,200.00   |              |            | 22/09/2025     |               |                |
|         | State Pension | State Pension              | Monthly     | £ 0.00         | £ 230.00     |              |            | 22/09/2025     |               |                |

## Income Changes

Do you expect any changes in your income in the foreseeable future?

No

No

No

£ 0.00

£1,430.00

No

Total

£0.00

<!-- page: 9 -->

## Expenditure

Do you wish to carry out a detailed expenditure analysis? If 'no' then please enter a value into the Total Monthly Expenditure field

Yes

| Category                               | Owner                       | Description      | Net Amount   | Frequency   |
|----------------------------------------|-----------------------------|------------------|--------------|-------------|
| Basic Essential Expenditure            | Basic Essential Expenditure |                  |              |             |
| Rent                                   |                             |                  | £ 600.00     | Monthly     |
| Council Tax                            |                             |                  | £ 200.00     | Monthly     |
| Electricity                            |                             |                  | £ 120.00     | Monthly     |
| Water                                  |                             |                  | £ 60.00      | Monthly     |
| Telephone/Mobile                       |                             |                  |              |             |
| Food & Personal Care                   |                             |                  | £ 300.00     | Monthly     |
| Car/Travelling Expenses                |                             |                  | £ 150.00     | Monthly     |
| Housekeeping                           |                             |                  |              |             |
| Building Insurance                     |                             |                  | £ 25.00      | Monthly     |
| Combined Utilities                     |                             |                  |              |             |
| Maintenance/Alimony                    |                             |                  |              |             |
| Other (Basic Essential)                |                             | Gadget Insurance | £ 25.00      | Monthly     |
| Basic Quality of Living                |                             |                  |              |             |
| Clothing                               |                             |                  |              |             |
| TV/Satellite/Internet/Basic Recreation |                             |                  | £ 138.00     | Monthly     |
| School Fee/Childcare                   |                             |                  |              |             |
| Other (Basic Quality of Living)        |                             |                  |              |             |
| Non-Essential Outgoings                |                             |                  |              |             |
| Sports and Recreation                  |                             |                  |              |             |
| Holidays                               |                             |                  |              |             |
| Entertainment                          |                             |                  | £ 100.00     | Monthly     |
| Life/General Assurance Premium         |                             |                  |              |             |
| Other (Non-Essential)                  |                             |                  |              |             |
| Liability Expenditure                  |                             |                  |              |             |
| Mortgage                               |                             |                  |              |             |
| Other (Liability)                      |                             |                  |              |             |

## Expenditure Details

| Calculated Total Monthly Household Expenditure                           | £ 1,718.00   |
|--------------------------------------------------------------------------|--------------|
| Do you expect any changes in your expenditure in the foreseeable future? | No           |

<!-- page: 10 -->

## Current Monthly Cash Flow

| Total Net Monthly Income        | £ 1,430.00   |
|---------------------------------|--------------|
| Total Monthly Expenditure       | £ 1,718.00   |
| Total Monthly Disposable Income | £ -288.00    |

## Modelling Monthly Affordability

| Do you wish to incorporate expected income changes?                                |            |
|------------------------------------------------------------------------------------|------------|
| Do you wish to incorporate expected expenditure changes?                           |            |
| Do you wish to forgo non-essential expenditure for this solution?                  |            |
| Do you wish to exclude existing liability expenditure which is to be consolidated? |            |
| Do you wish to exclude existing liability expenditure which is to be repaid?       |            |
| Revised Monthly Income Available                                                   | £ 1,430.00 |
| Revised Monthly Expenditure                                                        | £ 1,718.00 |
| Consolidated Expenditure Payments                                                  | £ 0.00     |
| To be Repaid Expenditure Payments                                                  | £ 0.00     |
| Current Protection Premiums                                                        | £ 0.00     |
| Revised Total Disposable Monthly Income Available                                  | £ -288.00  |
| Agreed Monthly Budget                                                              |            |
| Additional Notes                                                                   |            |

## Emergency Funds

| Amount put aside for Emergency Fund   | £ 6,000.00   |
|---------------------------------------|--------------|
| Amount of Emergency Fund Required     | £ 6,000.00   |
| Emergency Fund Shortfall              | £ 0.00       |

## Lump Sum Affordability

| Total Lump Sum available for this Advice Session (including any emergency funds)   |        |
|------------------------------------------------------------------------------------|--------|
| Total Funds Available                                                              | £ 0.00 |
| Agreed single amount for investment                                                |        |
| Source of Investment Funds                                                         |        |
| Are these funds available without penalty?                                         | No     |
| Additional Notes                                                                   |        |

<!-- page: 11 -->

Budget Notes

<!-- page: 12 -->

## Retirement Goals &amp; Objectives

|                                                           |                                                                                                                                                                                                                                                        | Owner     |
|-----------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------|
|                                                           | Income at retirement                                                                                                                                                                                                                                   | Category  |
|                                                           | Retirement Planning                                                                                                                                                                                                                                    | Name      |
|                                                           | Just needs advice helping him organise his pensions in the best place. Wants to consolidate to help him get his head around what he has. Thinks he'll probably retire in the next 2 years and needs a household income of £1,700 net per month. ATR 5. | Details   |
| Time                                                      | Short Term                                                                                                                                                                                                                                             | Horizon   |
| Lump Sum                                                  |                                                                                                                                                                                                                                                        | Type      |
| Lump Sum Value                                            |                                                                                                                                                                                                                                                        |           |
| Regular Income (Today's Money)                            | £1,700.00                                                                                                                                                                                                                                              |           |
| Regular Income (Future Money)                             |                                                                                                                                                                                                                                                        |           |
| Income                                                    | Monthly                                                                                                                                                                                                                                                | Frequency |
|                                                           |                                                                                                                                                                                                                                                        | Term      |
| Target Age                                                | 72                                                                                                                                                                                                                                                     |           |
| Do you have any investment preferences (for example ESG)? | No                                                                                                                                                                                                                                                     |           |
| Investment Preference Details                             |                                                                                                                                                                                                                                                        |           |
| Risk                                                      | Medium Risk                                                                                                                                                                                                                                            | Profile   |

## Retirement Goals &amp; Objectives Notes

Just needs advice helping him organise his pensions in the best place. Wants to consolidate to help him get his head around what he has. Thinks he'll probably retire in the next 2 years and needs a household income of £1,700 net per month. ATR 5.

<!-- page: 13 -->

## Existing Pension Provision

Does your employer currently operate a pension scheme?

Yes

Are you a member?

Yes

| Owner                         |                                   |                       |     |
|-------------------------------|-----------------------------------|-----------------------|-----|
| Contract Type                 | Personal Pension Plan             | Personal Pension Plan |     |
| Product Name                  | Personal Pension (Uncrystallised) |                       |     |
| Provider                      | Aviva Platform                    | The Peoples Pension   |     |
| Linked To (Policy Number)     | AV2936864                         |                       |     |
| Linked To (PlanType/Provider) | Wrap/Aviva Platform               |                       |     |
| Policy No                     | AV2936864-001                     | 6197175/PP            |     |
| Agency Status                 | Under Agency - Servicing Agent    | Not Under Agency      |     |
| Currency                      | GBP                               | GBP                   |     |
| Policy Start Date             | 09/12/2025                        |                       |     |
| Ret.                          |                                   |                       | Age |
| Your Cont. (reg)              |                                   |                       |     |
| Emp. Cont. (reg)              |                                   |                       |     |
| Freq.                         |                                   |                       |     |
| Transfer Cont.                |                                   |                       |     |
| Lump Sum Cont.                |                                   |                       |     |
| Value                         | £ 116,555.45                      |                       |     |
| Valuation Date                | 23/07/2026                        |                       |     |
| Pension Arrangement           |                                   |                       |     |
| Crystallisation Status        |                                   |                       |     |

Are you a member?

Yes

## State Pension Entitlement

State Pension Retirement Age:

Basic State Pension

Additional State Pension

Pension Credit

Spouses Pension

BR19 Projection

Notes

## Final Salary Pension Schemes

Do you have any existing final salary schemes?

No

## Money Purchase Pension Schemes

Do you have any existing money purchase schemes?

No

## Personal Pensions

Do you have any existing Personal Pension arrangements?

Yes

Client did not disclose

No

Owner

Contract Type

Personal Pension Plan

Personal Pension Plan

Product Name

Personal Pension (Uncrystallised)

Provider

Aviva Platform

The Peoples Pension

Linked To (Policy Number)

AV2936864

Linked To (PlanType/Provider)

Wrap/Aviva Platform

Policy No

AV2936864-001

6197175/PP

Agency Status

Under Agency - Servicing Agent

Not Under Agency

Currency

GBP

GBP

Policy Start Date

09/12/2025

Ret. Age

Your Cont. (reg)

Emp. Cont. (reg)

Freq.

Transfer Cont.

Lump Sum Cont.

Value

£

116,555.45

Valuation Date

23/07/2026

Pension Arrangement

Crystallisation Status

<!-- page: 14 -->

| Crystallised Percentage - Pre 6th April 2024   |          |          |           |
|------------------------------------------------|----------|----------|-----------|
| Crystallised Percentage - Post 6th April 2024  |          |          |           |
| Total Crystallised Percentage                  |          |          |           |
| Uncrystallised Percentage                      |          |          |           |
| PCLS                                           |          |          |           |
| PCLS Paid                                      |          |          | By        |
| Protected                                      |          |          | PCLS      |
| GAD / Maximum Income Limit (p.a.)              |          |          |           |
| Guaranteed / Minimum Income (p.a.)             |          |          |           |
| GAD Calculation Date                           |          |          |           |
| Next Review                                    |          |          | Date      |
| Capital / Value Protected?                     |          |          |           |
| Capital / Value Protected Amount               |          |          |           |
|                                                |          |          | Indexed?  |
| Preserved?                                     |          |          |           |
| Lump Sum Death                                 |          |          | Benefit   |
|                                                |          |          | In Trust? |
|                                                | In force | In force | Status    |
| GMP Amount (p.a.)                              |          |          |           |
| Enhanced Tax Free Cash                         |          |          |           |
| Guaranteed Annuity Rate / Pension (or similar) |          |          |           |
| Applicable Penalties                           |          |          |           |
| EFI/Loyalty Bonus/Terminal Bonus               |          |          |           |
| Guaranteed Growth Rates                        |          |          |           |
| Death in service spousal benefits              | £ 0.00   |          |           |
| Lifetime Allowance Used (%)                    |          |          |           |
| Lifestyling strategy?                          |          |          |           |
|                                                |          |          | Details   |
| Options Available at Retirement                |          |          |           |
| Other Benefits and/or Material Features        |          |          |           |
| Additional Notes                               |          |          |           |

## Annuities

Do you have any existing Annuity plans?

## Retirement Risk Profile

No

<!-- page: 15 -->

## Retirement Risk Replay

Generated Risk Profile

Do you agree with the generated Risk Profile?

Notes

Date Completed

//

## Notes

## Marketing

Do you wish to be contacted for marketing purposes?

Related Products/Services Only

Consent Date

01/09/2025

Please contact me by phone for marketing purposes

Please send me marketing information by mail

- [x] Please send me marketing information by e-mail

- [ ] Please send me marketing information by SMS text, picture messaging or by any other personal means of contact apart from mail, telephone or email

- [ ] Please send me marketing information or contact me through Social Media

- [ ] Please contact me by automated calls for marketing purposes

- [ ] Please send me marketing information by PFP

Accessible format requirement

No Requirement

Preferred delivery method

No Preference

## Declaration

Date Fact Find Completed

19/09/2025

Date ID/AML Checked

Date Declaration Signed

- [ ] ☑

- [ ] □

<!-- page: 16 -->

## Additional Notes

<!-- page: 17 -->

## Our Acknowledgements

Subject to the marketing preferences selected, any member of The Financial Advice Service Ltd may contact you by post, phone or e-mail, or in any other way a member feels is appropriate. Copies of the proposal forms and other documentation may also be held. These may contain sensitive personal data as defined by legislation e.g. health details.

Sensitive personal data will only be used to provide and administer the services or products applied for. By signing below you explicitly consent to The Financial Advice Service Ltd processing your sensitive personal data as described above and below. Please inform us by writing to the address below if you do not wish for such information to be retained.

Second Floor St. Andrew House, 119-121 The Headrow, Leeds, West Yorkshire, United Kingdom, LS1 5JW

## Client Declaration

I/We the undersigned confirm a copy of the Client Agreement and the Financial Planner's Business Card have been handed to me/us.

I/We the undersigned confirm that the information provided in this review is correct and is given on the understanding that it does not place me/us under any obligation to buy or take up any recommendation which may be made and that a copy of this form is available on request. I/We the undersigned confirm my/our financial planning objectives are those identified and prioritised in this document.

I/We the undersigned authorise The Financial Advice Service Ltd to obtain quotations/details of existing Pension policies and make recommendations for my/our consideration.

Signed

...............................................

Signed

...............................................

Date

...............................................

Date

...............................................
